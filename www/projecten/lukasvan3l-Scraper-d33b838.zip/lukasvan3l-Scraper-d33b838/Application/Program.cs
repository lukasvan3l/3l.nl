﻿using System;
using System.IO;
using System.Net;
using System.Xml;
using Sgml;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Web;

namespace Scraper
{
  class Program
  {
    private const string url = "http://www.worldsex.com";
    private static List<String> donot = new List<string>() { "granny", "machine", "posing", "mama", "shemale", "asian", "gay", "movies", "mum", "amateur", "mature", "fatty", "boy", "hairy", "furry", "strapon" };
    private static List<String> doto = new List<string>() { "fucked", "doubled", "poked", "rammed", "banged", "nailed", "sucking", "stuffed", "fucks", "cock", "3some", "cumshot", "facialized", "horny", "drilled", "doggiestyled", "cock", "dick", "threesome", "couple", "fucks" };

    public static void Main(string[] args)
    {
      Console.WriteLine("Starting up for url " + url);
      XmlDocument doc = GetXml(url);

      Regex donotRegex = GetRegex(donot);
      Regex dotoRegex = GetRegex(doto);

      XmlNodeList links = doc.SelectNodes("//table[@class='galleries']//a[@href!='']");
      foreach (XmlElement link in links)
      {
        string txt = link.InnerText.ToLower();
        if (donotRegex.Match(txt).Success) continue;
        if (!dotoRegex.Match(txt).Success) continue;
        ScrapePictures(link.GetAttribute("href"), txt);
      }

      Console.ReadKey(true);
    }

    private static void ScrapePictures(string url, string title)
    {
      Console.WriteLine("found link " + title + " at " + url);
      XmlDocument doc;
      try
      {
         doc = GetXml(url);
      }
      catch (Exception)
      {
        return;
      }

      foreach (XmlElement el in doc.SelectNodes("//a[@href!='']"))
      {
        string imgurl = el.GetAttribute("href").ToLower();
        if (imgurl.EndsWith(".jpg") && !imgurl.StartsWith("http://"))
        {
          Uri imgUri;
          if (Uri.TryCreate(new Uri(url), imgurl, out imgUri))
            try
            {
              DownloadImage(imgUri, title);
              Console.WriteLine("IMAGE " + imgUri.ToString());
            }
            catch (Exception ex)
            {
              Console.WriteLine("Error downloading: " + ex.Message);            
            }
        }
      }

    }

    private static void DownloadImage(Uri file, string title)
    {
      byte[] b;
      HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create(file.ToString());

      using (WebResponse myResp = myReq.GetResponse())
      {
        b = ReadFully(myResp.GetResponseStream(), 32768);
      }

      string filename = title + " - " + file.Segments[file.Segments.Length - 1].ToString();
      string filePath = Path.Combine(@"c:\Users\Lukas\Downloads\_x\", filename);
      using (FileStream fs = new FileStream(filePath, FileMode.Create))
      {
        using (BinaryWriter w = new BinaryWriter(fs))
        {
          w.Write(b);
        }
      }
    }

    private static Regex GetRegex(List<string> words)
    {
      string pattern = "";
      foreach (string s in words)
        pattern += s + "|";
      return new Regex(pattern.TrimEnd('|'));
    }

    private static XmlDocument GetXml(string url)
    {
      HttpWebRequest req = WebRequest.Create(url) as HttpWebRequest;
      req.KeepAlive = true;
      HttpWebResponse res = null;

      res = req.GetResponse() as HttpWebResponse;
      XmlDocument doc = new XmlDocument();
      Console.WriteLine("Reading response stream from " + url);
      using (Stream stream = res.GetResponseStream())
      {
        using (StreamReader streamReader = new StreamReader(stream))
        {
          Console.WriteLine("response found, converting to XHTML");
          SgmlReader r = new SgmlReader();
          //r.SetBaseUri(BaseWebsitePath);
          r.DocType = "HTML";
          r.InputStream = new StringReader(streamReader.ReadToEnd());
          r.CaseFolding = CaseFolding.ToLower;
          StringWriter sw = new StringWriter();

          XmlTextWriter w = new XmlTextWriter(sw);
          w.Formatting = Formatting.None;
          while (!r.EOF)
            w.WriteNode(r, true);
          w.Close();
          r.Close();

          doc.InnerXml = sw.ToString();
        }

      }
      res.Close();
      return doc;
    }

    /// <summary>
    /// Reads data from a stream until the end is reached. The
    /// data is returned as a byte array. An IOException is
    /// thrown if any of the underlying IO calls fail.
    /// </summary>
    /// <param name="stream">The stream to read data from</param>
    /// <param name="initialLength">The initial buffer length</param>
    public static byte[] ReadFully(Stream stream, int initialLength)
    {
      // If we've been passed an unhelpful initial length, just
      // use 32K.
      if (initialLength < 1)
      {
        initialLength = 32768;
      }

      byte[] buffer = new byte[initialLength];
      int read = 0;

      int chunk;
      while ((chunk = stream.Read(buffer, read, buffer.Length - read)) > 0)
      {
        read += chunk;

        // If we've reached the end of our buffer, check to see if there's
        // any more information
        if (read == buffer.Length)
        {
          int nextByte = stream.ReadByte();

          // End of stream? If so, we're done
          if (nextByte == -1)
          {
            return buffer;
          }

          // Nope. Resize the buffer, put in the byte we've just
          // read, and continue
          byte[] newBuffer = new byte[buffer.Length * 2];
          Array.Copy(buffer, newBuffer, buffer.Length);
          newBuffer[read] = (byte)nextByte;
          buffer = newBuffer;
          read++;
        }
      }
      // Buffer is now too big. Shrink it.
      byte[] ret = new byte[read];
      Array.Copy(buffer, ret, read);
      return ret;
    } 

  }
}