using System;
using System.IO;
using System.Net;

namespace Q42.Wheels.Download
{
  /// <summary>
  /// Utility for down- and uploading via FTP
  /// </summary>
  public static class FtpConnector
  {

    /// <summary>
    /// Download the contents of the fileLocation and return it as a string
    /// </summary>
    /// <param name="fileLocation">Full path to the file on the ftp server. Should start with ftp://</param>
    /// <param name="username"></param>
    /// <param name="password"></param>
    /// <returns>Total file contents as a string</returns>
    public static string GetFileContents(string fileLocation, string username, string password)
    {
      if (string.IsNullOrEmpty(fileLocation) || !fileLocation.StartsWith("ftp://"))
        throw new ArgumentException("No filelocation present or invalid: " + fileLocation);
      if (string.IsNullOrEmpty(username))
        throw new ArgumentException("No username present");
      if (string.IsNullOrEmpty(password))
        throw new ArgumentException("No password present");

      string result = null;

      // wat gebeurt er als de server down is? Het connecten duurt dan ONTZETTEND erg lang!

      FtpWebRequest request = (FtpWebRequest)WebRequest.Create(fileLocation);
      request.Method = WebRequestMethods.Ftp.DownloadFile;
      request.KeepAlive = false;
      request.Timeout = 2000; // 3 seconden wachten maximaal
      request.Credentials = new NetworkCredential(username, password);

      //FtpWebResponse response = null;
      using (FtpWebResponse response = request.GetResponse() as FtpWebResponse)
      {
        if (response != null)
        {
          using (Stream responseStream = response.GetResponseStream())
          {
            using (StreamReader reader = new StreamReader(responseStream))
            {
              result = reader.ReadToEnd();             
            }
          }
        }
      }

      return result;
    }
  }
}