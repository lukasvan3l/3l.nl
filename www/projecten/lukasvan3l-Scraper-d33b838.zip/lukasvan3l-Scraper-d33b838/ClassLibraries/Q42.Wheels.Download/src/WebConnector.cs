using System;
using System.IO;
using System.Net;
using System.Xml;
using System.Xml.XPath;

namespace Q42.Wheels.Download
{

  /// <summary>
  /// Utility for downloading content from a webserver
  /// </summary>
  public static class WebConnector
  {

    /// <summary>
    /// Gets the information from the URL as XmlDocument
    /// </summary>
    /// <param name="url"></param>
    /// <returns></returns>
    public static XmlDocument GetXML(string url)
    {
      if (string.IsNullOrEmpty(url))
        throw new ArgumentException("Missing argument url");

      HttpWebRequest req = WebRequest.Create(url) as HttpWebRequest;
      req.KeepAlive = true;
      HttpWebResponse res = null;

      res = req.GetResponse() as HttpWebResponse;
      XmlDocument doc = new XmlDocument();
      using (Stream stream = res.GetResponseStream())
        doc.Load(stream);
      res.Close();

      return doc;
    }

  }
}