using System.IO;
using System.Xml;
using Sgml;
using System.Xml.XPath;

namespace Q42.Wheels.HtmlTidy
{
  
  /// <summary>
  /// Utility for creating XHTML
  /// </summary>
  public static class SgmlMethod
  {

    /// <summary>
    /// convert a string to XHTML, using SgmlReader
    /// </summary>
    /// <param name="html"></param>
    /// <param name="settings"></param>
    /// <returns></returns>
    public static XmlDocument MakeXhtml(string html, string BaseWebsitePath)
    {
      html = html.Replace("xmlns=", "xmlnsx=");

      SgmlReader r = new SgmlReader();
      r.SetBaseUri(BaseWebsitePath);
      r.DocType = "HTML";
      r.InputStream = new StringReader(html);
      r.CaseFolding = CaseFolding.ToLower;
      StringWriter sw = new StringWriter();

      XmlTextWriter w = new XmlTextWriter(sw);
      w.Formatting = Formatting.None;
      while (!r.EOF)
        w.WriteNode(r, true);
      w.Close();
      r.Close();

      XmlDocument result = new XmlDocument();
      result.InnerXml = sw.ToString();

      return result;
    }

    /// <summary>
    /// Only convert \r\n to BR, and replace double BR with P
    /// </summary>
    /// <param name="html"></param>
    /// <returns></returns>
    public static string ConvertEntersToBR(string html)
    {
      html = "<p>" + html + "</p>";
      html = html.Replace("\r\n", "<br />");
      html = html.Replace("\n", "<br />");
      html = html.Replace("<br /><br />", "</p><p>");
      return html;
    }

  }
}
